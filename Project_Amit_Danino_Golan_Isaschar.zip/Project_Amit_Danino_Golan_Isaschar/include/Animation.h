#pragma once
#include <SFML/Graphics.hpp>
#include "Consts.h"
class Coin;
class Player;
class Enemy;

class animation
{
public:
	animation();
	void setCoinTextures();
	void setEnemyTextures();
	void setPlayerTextures();
	void setLifeTextures();

	sf::Sprite objectAnimation(Coin& gameObject , const sf::Sprite &mycorrentsprite);
	sf::Sprite objectAnimation(Player& gameObject, const sf::Sprite& mycorrentsprite , 
		const bool &onLadder , const bool& onPole , const int &direction);
	sf::Sprite objectAnimation(Enemy& gameObject, const sf::Sprite& mycorrentsprite , 
		const bool& onLadder, const bool& onPole, const int& direction);
	sf::Sprite life(const sf::Sprite& mycorrentsprite , bool &finish);
	
private:

	const float m_timeNedeed = 0.1f;
	sf::Clock m_coinClock;
	int m_coinPicIndex = 0;
	std::vector <sf::Texture> m_coinTexture;

	sf::Clock m_playerClock;
	int m_playerPicIndex = 0;
	std::vector <sf::Texture> m_playerRightTexture;
	std::vector <sf::Texture> m_playerLeftTexture;
	std::vector <sf::Texture> m_playerLadderTexture;

	sf::Clock m_enemyClock;
	int m_enemyPicIndex = 0;
	std::vector <sf::Texture> m_enemyRightTexture;
	std::vector <sf::Texture> m_enemyLeftTexture;
	std::vector <sf::Texture> m_enemyLadderTexture;


	sf::Clock m_lifeClock;
	int m_lifePicIndex = 0;
	std::vector <sf::Texture> m_lifeTexture;
};


