#pragma once
#include "GameObject.h"
class Unmovable;
#include "Enemy.h"
#include "Player.h"
class Coin;
class WallOrFloor;
class Pole;
class Present;


class Ladder : public Unmovable
{
public:
    void handleCollision(GameObject& gameObject) override
    {
        if (&gameObject == this) return;
        gameObject.handleCollision(*this);
    }

    void handleCollision(Player& gameObject) override
    {
        gameObject.handleCollision(*this);
        gameObject.setLocation(m_sprite.getPosition());
      
    }

    void handleCollision(Coin& /*gameObject*/) override{}
    
    void handleCollision(Enemy& gameObject) override
    {
        gameObject.handleCollision(*this);
        gameObject.setLocation(m_sprite.getPosition());
    }
    void handleCollision(WallOrFloor& /*gameObject*/) override{}
    void handleCollision(Ladder& /*gameObject*/) override{}
    void handleCollision(Pole& /*gameObject*/) override{}
    void handleCollision(Present& /*gameObject*/) override{}
    void myAnimation() override {}
    void setWalls(std::vector <sf::Sprite >&) override {}

    std::pair<sf::Vector2f, bool > getPlayerHole() const override {
        return { {0,0}, 0 };
    }
    void setPlayerHole(std::pair<sf::Vector2f, bool >) override {}
};

