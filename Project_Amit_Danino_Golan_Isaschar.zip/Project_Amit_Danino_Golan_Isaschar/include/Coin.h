#pragma once
#include "GameObject.h"
#include "Animation.h"
class Unmovable; 
class Player;
class Enemy;
class WallOrFloor;
class Ladder;
class Pole;
class Present; 

class Coin : public Unmovable
{
public:
  
    void handleCollision(Coin& /*gameObject*/) override {}
    void handleCollision(Enemy& /*gameObject*/) override {}
    void handleCollision(WallOrFloor& /*gameObject*/) override {}
    void handleCollision(Ladder& /*gameObject*/) override {}
    void handleCollision(Pole& /*gameObject*/) override {}
    void handleCollision(Present& /*gameObject*/) override {}
    void setWalls(std::vector <sf::Sprite >& ) override {}
    std::pair<sf::Vector2f, bool > getPlayerHole() const override { return { {0,0}, 0 }; }
    void setPlayerHole(std::pair<sf::Vector2f, bool >) override {}

    void handleCollision(GameObject& gameObject) override
    {
        if (&gameObject == this) return;
        gameObject.handleCollision(*this);
    }

    void handleCollision(Player& gameObject) override
    {
        m_isDisposed = true;
        gameObject.handleCollision(*this);
    }
    void myAnimation() override 
    {
        m_sprite = m_animation.objectAnimation(*this , m_sprite);
    }

private :
    animation m_animation;
};