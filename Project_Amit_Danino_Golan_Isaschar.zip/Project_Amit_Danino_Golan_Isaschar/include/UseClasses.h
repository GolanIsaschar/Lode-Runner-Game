#pragma once
#include <vector>
#include <memory>
#include <SFML/Graphics.hpp>
#include "SFML/Audio.hpp"
#include "Animation.h"
#include "Consts.h"
using namespace std;

class dataBar {
public:
	dataBar();
	void draw(sf::RenderWindow& window, const int& level, const int& life,
		const int& score, bool& lifeAnimation, const int& time, const bool& timeAlart);
	void printData(const string& print, const sf::Vector2f& location, sf::RenderWindow& window);
	sf::Sprite gotScorePresent(const sf::Sprite& mycorrentsprite);
	void setScorePresent();
	void setLifePresent();
	void setTimePresent();
private:
	animation m_lifeAnimation;
	sf::Font m_arial;
	sf::Text m_text;
	sf::Texture  m_lifeRegularPic, m_noTimeLimmitPic, m_coinPresentRecived , 
		m_timePresentRecived , m_lifePresentRecived;
	sf::Sprite m_lifePic, m_noTimeLimmit, m_regularLifePic, m_coinPresentSprite , 
		m_timePresentSprite , m_lifePresentSprite;
	const float m_timeNedeed = 0.1f;
	sf::Clock m_PresentsUpdateClock;
	bool m_scorePresent, m_timePresent, m_lifePresent;
	bool m_Present;
};

class music {
public:
	void continueGameMusic();
	void playMusic(const string& musicfile, const bool& loop);
	void newGameMusic(const string& musicfile, const bool& loop);
	void exitMenuMusic(const string& musicfile, const bool& loop);

private:
	sf::Music m_music[2];
};

class timer {
public:
	timer();
	std::pair <bool, bool >  doesTimeAlarm();
	void resetTime(const int& time);
	int getTime() const;
	bool getTimeAlart() const;
	void addTimePresent();

private:
	bool m_timerAlart;
	float m_timeLeft;
	sf::Clock m_aITimer;
	int m_time;
};

class gameMenu {
public:
	void menu(sf::RenderWindow& window);
private:
};
