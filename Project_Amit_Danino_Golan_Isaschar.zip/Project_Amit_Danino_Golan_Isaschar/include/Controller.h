#pragma once
#include "ObjectsPtrsHandler.h"
#include "Animation.h"
#include "UseClasses.h"

class Controller {
public:
    Controller();
    void run();
private:
	void draw();
	void NewGame(const std::string& PicName);
	void win();
	void lost();
	void handleMove();
	void resetInfo();
	void Disqualified();
	void updata();

	ObjectsPtrsHandler m_ptrClass;
	dataBar m_dataBar;
	music m_music;
	timer m_timer;
	gameMenu m_gameMenu;

	sf::RenderWindow m_window;
	sf::Texture m_backround;
	sf::Sprite m_backgroundPic;
	bool m_doesLifeAnimation;
	int m_level, m_life , m_saveLastLevelsScore;
};