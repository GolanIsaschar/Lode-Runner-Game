#pragma once
#include <vector>
#include <memory>
#include "GameObject.h"
#include "MoovingObject.h"
#include "Board.h"
#include "Consts.h"
#include "SFML/Audio.hpp"
#include "WallOrFloor.h"
#include "Ladder.h"
#include "Pole.h"
#include "Present.h"
#include "animation.h"

class ObjectsPtrsHandler {

public:
	ObjectsPtrsHandler();
	void move(sf::Event& event, const float& deltaTime);
	void draw(sf::RenderWindow &window);
	void resetInfo(const int& level);
	int returnScore() const;
	int returnTime(const int& level) const;
	vector <int> getPtrEvents() const;
	int returnAmountOfLevels() const;
	bool returnTimePresent() const;
	bool returnScorePresent() const;
	bool returnLifePresent() const;
	bool returnIsDispose() const;
	bool returnIfCoinOver() const;
	bool returnEnemyPresent();

private:
	void addEnemy();
	void handleCollisions(GameObject& gameObject);
	void createObject(const int& type, const int& index);
	void eraseUnmovable();
	int returnWhichPresent();
	Board m_board;
	vector <int> m_events;
	pair < std::vector<int>, std::vector<std::unique_ptr<MoovingObject>>> m_movables;
	pair < std::vector<int>, std::vector<std::unique_ptr<Unmovable>>> m_unmovables; 
	int m_playerIndex;
	bool m_enemy ;
};