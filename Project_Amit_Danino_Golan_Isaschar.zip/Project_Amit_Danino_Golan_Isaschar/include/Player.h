#pragma once
#include "MoovingObject.h"
#include "Consts.h"
#include "Animation.h"
class Coin;
class Enemy; 
class WallOrFloor;
class Ladder;
class Pole;
class Present;
class Unmovable;
class CoinPresent;
class ScorePresent;
class EnemyPresent;
class TimePresent;
class LifePresent;

class Player : public MoovingObject
{
public:
    Player();
    void handleCollision(WallOrFloor& gameObject) override;
    void handleCollision(GameObject& gameObject) override;
    void handleCollision(Player& /*gameObject*/) override;
    void handleCollision(Coin& gameObject) override;
    void handleCollision(Enemy& gameObject) override;
    void handleCollision(Ladder& gameObject) override;
    void handleCollision(Pole& gameObject) override;
    void handleCollision(Present&  /*gameObject*/) override;
    void handleCollision(ScorePresent& gameObject);
    void handleCollision(EnemyPresent& gameObject);
    void handleCollision(TimePresent& gameObject);
    void handleCollision(LifePresent& gameObject);

    void move(const sf::Event& event, float deltaTime) override; 
    void myAnimation() override;
    sf::Vector2f getPlayerPos() const override;
    void setPlayerPos(const sf::Vector2f&) override {}
    std::pair<sf::Vector2f, bool > getPlayerHole() const override {
        return m_hole;}
    void setPlayerHole(std::pair<sf::Vector2f, bool >) override {}
    void setLocation(const sf::Vector2f &loc);
    void makeHole(const sf::Event& event);
    void inHole(const sf::Vector2f& loc);

private:
    const float playerSpeed = 300.f;  
    animation m_animation;
    const float m_timeNedeed = 3.0f;
    sf::Clock clock;
    bool m_playerInsideHole, m_enemyAllreadyInside;
    sf::Vector2f m_aboveHoleLoc;
};
