#pragma once
#include <iostream>
#include <fstream>
#include <thread>

const std::string FileNames[9] = { "coin1.png" , "enemyright1.png" , "LADDER.png" , "playerright1.png" ,
"POLE.png" , "WALLFLOOR.png" , "PRESENT.png" , "HOLE.png"  , "rec.png"};
const std::string lifeImage = "LIFE.png";
enum FileNamesPosition {
	COIN, ENEMY, LADDER, PLAYER, POLE, WALLFLOOR, PRESENT, HOLE , DELETE
};
const int  WindowHeight = 1200, PicSize = 133, DATAPLACE = 300,
WindowWidth = 2000, NUMOFIMAGES = 9, DataBarSize = 4, MusicValume = 50,
NEXT_LEVEL_BONUS = 50, COIN_BONUS = 2, SCORE_PRESENT_BONUS = 10, FIRSTLEVEL = 1,
LIFES = 3;
const char PLAYER_CHAR = '@', ENEMY_CHAR = '%', COIN_CHAR = '*', LADDER_CHAR = 'H',
POLE_CHAR = '-', WALLFLOOR_CHAR = '#', PRESENT_CHAR = '+';
enum Data {
	LEVEL , SCORE , LIFE , TIME
};
const std::string GAMEOVERPIC = "GAMEOVER.jpg", YOUWINPIC = "YOUWIN.jpg",
NEWGAMEPIC = "GAME.jpg", NOTIMELIMIT = "notimelimit.png", BACKGROUNDPIC = "backroundgame.jpg" , 
 CoinPresentPicForMenu =  "CoinPresentUpdate.png" , TimePresentPicForMenu = "TimePresentUpdate.png" ,
	LifePresentPicForMenu = "LifePresentUpdate.png";

const std::string DataNames[4] = { "Level : " , "Score : " , "Life : " , "Time : " };

enum Music {
	COINMUSIC, GAMEMUSIC, NEWGAMEMUSIC , NEWLEVEL , VICTORY , LOST , CLOCK ,MINUSLIFE 
};
const std::string MusicNames[12] = { "coinmusic.wav" , "music.wav" ,
"Shallweplayagame.wav" , "passedlevel.wav" ,  "gameovervictory.wav"  ,
"gameoverlosser.wav"  , "clock.wav" , "minuslife.wav"  , "timepresent.wav" ,
"coinpresent.wav", "lifepresent.wav" , "enemypresent.wav" };

enum PRESENT {
	TIMEPRESENT = 8 , SCOREPRESENT , LIFEPRESENT , ENEMYPRESENT
};
const std::string coinPic[9] = { "coin1.png" , "coin2.png" , "coin3.png" , "coin4.png" ,
"coin5.png" , "coin6.png" , "coin7.png" ,"coin8.png"  , "coin9.png" };
const std::string playerRightPic[5] = { "playerright1.png" , "playerright2.png" ,
"playerright3.png" , "playerright4.png" ,"playerright5.png" };
const std::string playerLeftPic[5] = { "playerleft1.png" , "playerleft2.png" ,
"playerleft3.png" , "playerleft4.png" ,"playerleft5.png" };
const std::string enemyRightPic[5] = { "enemyright1.png" , "enemyright2.png" ,
"enemyright3.png" , "enemyright4.png" ,"enemyright5.png" };
const std::string enemyLeftPic[5] = { "enemyleft1.png" , "enemyleft2.png" ,
"enemyleft3.png" , "enemyleft4.png" ,"enemyleft5.png" };
const int UP = 73, LEFT = 71, RIGHT = 72, DOWN = 74;
const std::string lifePic[4] = { "life1.png" , "life2.png" ,
"life3.png" , "life4.png"};
const std::string backGroundPic[17] = { "background1.jpg" , "background2.jpg" ,
"background3.jpg" ,"background4.jpg" , "background5.jpg" ,  "background6.jpg" , "background7.jpg" ,
"background8.jpg" ,"background9.jpg" , "background10.jpg"  ,  "background11.jpg" , "background12.jpg" ,
"background13.jpg" ,"background14.jpg" , "background15.jpg" ,"background16.jpg" , "background17.jpg" };

enum ENEMYTYPE {
	RANDOM_ENEMY , CONST_ENEMY , SMART_ENEMY
};