#pragma once
#include "GameObject.h"
#include "Enemy.h"
#include "Player.h"
class Unmovable;
class Coin;
class Ladder;
class Pole;
class Present;

class WallOrFloor : public Unmovable
{
public:
    void handleCollision(Coin& /*gameObject*/) override {}
    void handleCollision(WallOrFloor& /*gameObject*/) override {}
    void handleCollision(Ladder& /*gameObject*/) override {}
    void handleCollision(Pole& /*gameObject*/) override {}
    void handleCollision(Present& /*gameObject*/) override {}
    void myAnimation() override {}
    void handleCollision(GameObject& gameObject) override;
    void handleCollision(Player& gameObject) override;
    void handleCollision(Enemy& gameObject) override;
    void setWalls(std::vector <sf::Sprite >& keep) override;
    std::pair<sf::Vector2f, bool > getPlayerHole() const { return { {0,0}, 0 }; }
    void setPlayerHole(std::pair<sf::Vector2f, bool > loc) override;

private:
    const float m_timeNedeed = 3.0f;
    sf::Clock clock;
    bool m_was = false;
    bool m_allreadysent = false;
};
