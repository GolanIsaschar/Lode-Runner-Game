#pragma once
using namespace std;
#include <SFML/Graphics.hpp>
#include "Consts.h"
#include <vector>
class Board 
{
public:
    Board();
    void openFile();
    void insertLevelsFromFile(ifstream& infile);
    void setKeep();
    void setLevelBoard(const int &level);
    int CharCases(const char& Char);
    pair <std::vector <int>, std::vector<sf::Sprite>> getBoard() const;
    unsigned int getTime(const int& level) const;
    unsigned int getAmountOfLevels() const;

private:
    vector<vector<vector<char>>> m_myOriginalLevels;
    std::vector <sf::Texture> m_keep;
    pair <std::vector <int> , std::vector<sf::Sprite>> m_sprites, m_OriginalSprite;
    std::vector< unsigned int > m_Height, m_Width, m_Time;
};
