#pragma once
#include "GameObject.h"
class Unmovable;
#include "Enemy.h"
#include "Player.h"
#include "Coin.h"
class WallOrFloor;
class Ladder;
class Pole;
class ScorePresent;
class EnemyPresent;
class TimePresent;
class LifePresent;

#include <string>
#include <iostream>
#include <experimental/vector>

class Present : public Unmovable
{
public:
    void handleCollision(GameObject& gameObject) override
    {
        if (&gameObject == this) return;
        gameObject.handleCollision(*this);
    }

    void handleCollision(Player& gameObject) override
    {
        m_isDisposed = true;
        int randPresent = rand() % 4;
       
        std::unique_ptr<ScorePresent> score = std::make_unique<ScorePresent>();
        std::unique_ptr<EnemyPresent> enemy = std::make_unique<EnemyPresent>();
        std::unique_ptr<TimePresent> time = std::make_unique<TimePresent>();
        std::unique_ptr<LifePresent> life = std::make_unique<LifePresent>();
      
        switch (randPresent)
        {
        case 0:
            gameObject.handleCollision(*score);
            break;
        case 1 :
            gameObject.handleCollision(*enemy);
        break;
        case 2 : 
            gameObject.handleCollision(*time);
        break;
        case 3:
            gameObject.handleCollision(*life);
            break;
        default:
            break;
        }
    }

    void handleCollision(Coin& /*gameObject*/) override{}
    void handleCollision(Enemy& /*gameObject*/) override{}
    void handleCollision(WallOrFloor& /*gameObject*/) override{}
    void handleCollision(Ladder& /*gameObject*/) override{}
    void handleCollision(Pole& /*gameObject*/) override{}
    void handleCollision(Present& /*gameObject*/) override{}
    virtual void myAnimation() override {}
    void setWalls(std::vector <sf::Sprite >&) override {}
    std::pair<sf::Vector2f, bool > getPlayerHole() const override {
        return { {0,0}, 0 };
    }
    void setPlayerHole(std::pair<sf::Vector2f, bool >) override {}

};

class ScorePresent : public Present
{
};
class EnemyPresent : public Present
{
};
class TimePresent : public Present
{
};
class LifePresent : public Present
{
};