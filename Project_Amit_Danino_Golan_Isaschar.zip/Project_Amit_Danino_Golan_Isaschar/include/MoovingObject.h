#pragma once
#include "GameObject.h"
#include "Consts.h"

class MoovingObject : public GameObject
{
public:
    enum presents
    {
        m_newEnemy, m_timepresent, m_lifepresent, m_scorepresent
    };
    MoovingObject();
    virtual void move(const sf::Event& event, float deltaTime) = 0;
    virtual sf::Vector2f getPlayerPos() const = 0;
    virtual void setPlayerPos(const sf::Vector2f& loc) = 0;

    sf::Vector2f GetMove(const unsigned int& direction, float deltaTime,
        const float& speed);

    bool fall();
    void checkIfMoovingObjectExitTheWindow();
    int returnScore() const;
    void setLocation(const sf::Vector2f& loc);
    bool getIfNewEnemy();
    bool getIfTimePresent();
    bool getIfLifePresent();
    bool getIfScorePresent();
    void checkIfValid();
    void setWalls(std::vector <sf::Sprite>& keep)override;
    void updatePlayerData(const int& level);

protected:
    std::vector <bool> m_presents{ false , false , false , false };
    bool m_OnPole, m_onLadder , m_floor, m_exit;
    int m_level , m_score , m_direction ;
    sf::Vector2f m_tempLoc, m_ladderLoc, m_poleLoc;
    sf::Vector2f m_playerPos{0,0};
    bool m_ladder = false, m_pole = false, m_moved = false;
    std::vector <sf::Sprite > m_keepWalls;
};