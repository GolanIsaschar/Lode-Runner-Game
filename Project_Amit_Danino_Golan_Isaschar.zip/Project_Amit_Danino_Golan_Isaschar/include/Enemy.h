#pragma once
#include "MoovingObject.h"
#include "Animation.h"
#include <vector>
#include <math.h>
class Player;
class Coin;
class WallOrFloor;
class Ladder;
class Pole;
class Present;
class Unmovable;
class smartEnemy;

class Enemy : public MoovingObject
{
public:
    Enemy();
    void handleCollision(GameObject& gameObject) override;
    void handleCollision(Player& /*gameObject*/) override;
    void handleCollision(Coin& /*gameObject*/) override;
    void handleCollision(Enemy& /*gameObject*/) override;
    void handleCollision(WallOrFloor& gameObject)override;
    void handleCollision(Ladder& gameObject) override;
    void handleCollision(Pole& gameObject) override;
    void handleCollision(Present& /*gameObject*/) override;
    void myAnimation() override;
    sf::Vector2f getPlayerPos() const override {return { 0,0 };};
    void setPlayerPos(const sf::Vector2f& loc) override;
    std::pair<sf::Vector2f, bool > getPlayerHole() const override { return { {0,0}, 0 }; }
    void setPlayerHole(std::pair<sf::Vector2f, bool >) override {}
    void setLocation(const sf::Vector2f& loc);
    void inHole(const sf::Vector2f& loc);

protected:
    animation m_animation;
    const float m_enemySpeed = 100.f;
    const float m_holetimeNedeed = 2.1f;
    sf::Clock m_holeclock;
    sf::Vector2f m_aboveHole;
    bool m_insideHole;
    int m_enemyDir;
};
class smartEnemy : public Enemy
{
    void move(const sf::Event& event, float deltaTime) override;

private:
    bool compareDistance(const sf::Vector2f& loc1, const sf::Vector2f& loc2);
    void calculatePossibleLocations();
    void byDistance();
    double locationDis(const int& i);
    void moveLeftOrRight();
    enum index
    {
        left, right, up, down
    };
    std::vector <sf::Vector2f> m_loc;
    std::vector<std::pair<double, int> > m_sortedDirections;
    bool m_exitLadder = false, m_finish = false;;
};

class randomMoveEnemy : public Enemy
{
public:
    void move(const sf::Event& event, float deltaTime) override;

private:
    sf::Clock m_randomMoveClock;
    const float  m_randomTimeMove = 2.0f;
    bool m_firstTime = true;
};

class constMoveEnemy : public Enemy
{
    void move(const sf::Event& event, float deltaTime) override;

private:
    bool m_firstTime = true;
};