#pragma once
#include <SFML/Graphics.hpp>
class Coin;
class MoovingObject; 
class Unmovable;
class WallOrFloor;
class Ladder;
class Pole;
class Present; 
class Player;
class Enemy;

class GameObject
{
public:
    bool checkCollision(const sf::FloatRect& floatRect) const
    {
        return m_sprite.getGlobalBounds().intersects(floatRect);
    }
    void setRectangle(const sf:: Sprite &sprite) {
        m_sprite = sprite;
    }
    virtual void handleCollision(GameObject& gameObject) = 0;
    virtual void handleCollision(Player& gameObject) = 0;
    virtual void handleCollision(Coin& gameObject) = 0;
    virtual void handleCollision(Enemy& gameObject) = 0;
    virtual void handleCollision(WallOrFloor& gameObject) = 0;
    virtual void handleCollision(Ladder& gameObject) = 0;
    virtual void handleCollision(Pole& gameObject) = 0; 
    virtual void handleCollision(Present& gameObject) = 0;
    virtual void myAnimation() = 0;
    virtual void setWalls(std::vector <sf::Sprite >& keep) = 0;
    virtual std::pair<sf::Vector2f, bool > getPlayerHole() const = 0;
    virtual void setPlayerHole(std::pair<sf::Vector2f, bool >) = 0;

    bool isDisposed() const
    {
        return m_isDisposed;
    }

    sf::FloatRect getGlobalBounds() const
    {
        return m_sprite.getGlobalBounds();
    }

    virtual ~GameObject() = default;
    sf::Sprite getMySprite() const {
        return m_sprite;
    }

protected:
    sf::Sprite m_sprite, m_temp;
    bool m_isDisposed = false, m_bumper = false;
    std::pair<sf::Vector2f, bool > m_hole;
};

class Unmovable : public GameObject
{
  
};