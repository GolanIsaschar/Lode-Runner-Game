#include "UseClasses.h"

//---THIS FUNCTION SET ALL THE IMAGES AND THE FONTS FOR THE DATA BAR
//========================================================================
dataBar::dataBar() : m_scorePresent(false) ,  m_timePresent(false), m_lifePresent(false) , 
m_Present(false){
    m_arial.loadFromFile("C:/Windows/Fonts/Arial.ttf");
    m_text.setFont(m_arial);
    m_text.setCharacterSize(50);
    m_lifePic.scale(0.5, 0.5);
    m_lifeRegularPic.loadFromFile(lifeImage);
    m_regularLifePic.setTexture(m_lifeRegularPic);
    m_regularLifePic.scale(0.5, 0.5);
    m_noTimeLimmitPic.loadFromFile(NOTIMELIMIT);
    m_noTimeLimmit.setTexture(m_noTimeLimmitPic);
    m_coinPresentRecived.loadFromFile(CoinPresentPicForMenu);
    m_coinPresentSprite.setTexture(m_coinPresentRecived);
    m_coinPresentSprite.setPosition(DATAPLACE*3, WindowHeight - DATAPLACE*2);
    m_timePresentRecived.loadFromFile(TimePresentPicForMenu);
    m_timePresentSprite.setTexture(m_timePresentRecived);
    m_timePresentSprite.setPosition(DATAPLACE * 5.8f, WindowHeight - DATAPLACE * 2);
    m_lifePresentRecived.loadFromFile(LifePresentPicForMenu);
    m_lifePresentSprite.setTexture(m_lifePresentRecived);
    m_lifePresentSprite.setPosition(DATAPLACE * 4.5f, WindowHeight - DATAPLACE * 2);
}
//---THIS FUNCTION DRAW THE DATA BAR INFO
//========================================================================
void dataBar::draw(sf::RenderWindow& window , const int &level , const int &life , 
    const int &score , bool &lifeAnimation , const int &time , const bool &timeAlart) {

    sf::Vector2f location(WindowWidth / 7, WindowHeight - DATAPLACE);
    m_text.setColor(sf::Color::Black);
    string datastring;

    for (int i = 0; i < DataBarSize; i++)
    {
        printData(DataNames[i], location , window);
        location.x += m_text.getGlobalBounds().width;
        switch (i)
        {
        case LEVEL:
            datastring = to_string(level);
            break;
        case SCORE:
            datastring = to_string(score);
            break;
        case LIFE:
            for (int i = 0; i < life; i++)
            {
                m_regularLifePic.setPosition(location.x + i * 50, location.y);
                window.draw(m_regularLifePic);
            }
            if (lifeAnimation)
            {
                bool finish = false;
                m_lifePic.setPosition(location.x + life * 50, location.y);
                m_lifePic = m_lifeAnimation.life(m_lifePic, finish);
                window.draw(m_lifePic);
                if (finish)
                    lifeAnimation = false;
            }
            break;
        case TIME:
            if (time == -1)
            {
                m_noTimeLimmit.setPosition(location);
                window.draw(m_noTimeLimmit);
            }
            else
            {
                if (timeAlart)
                    m_text.setColor(sf::Color::Red);
                datastring = to_string(time);
            }
            break;
        default:
            break;
        }
        if (i != LIFE && !(i == TIME && time == -1))
            printData(datastring, location , window);
        location.x += DATAPLACE;
    }
    if (m_Present)
    {
        if (m_scorePresent)
        {
            m_coinPresentSprite = gotScorePresent(m_coinPresentSprite);
            window.draw(m_coinPresentSprite);
        }
        if (m_timePresent)
        {
            m_timePresentSprite = gotScorePresent(m_timePresentSprite);
            window.draw(m_timePresentSprite);
        }
        if (m_lifePresent)
        {
            m_lifePresentSprite = gotScorePresent(m_lifePresentSprite);
            window.draw(m_lifePresentSprite);
        }
    }
    else
    {
        m_coinPresentSprite.setPosition(DATAPLACE * 3, WindowHeight - DATAPLACE * 2);
        m_timePresentSprite.setPosition(DATAPLACE * 5.8f, WindowHeight - DATAPLACE * 2);
        m_lifePresentSprite.setPosition(DATAPLACE * 4.5f, WindowHeight - DATAPLACE * 2);
    }
}
//---THIS FUNCTION DRAW THE STRINGS BEFORE EVERY DATA
//========================================================================
void dataBar::printData(const string& print, const sf::Vector2f& location , 
    sf::RenderWindow& window) {

    m_text.setString(print);
    m_text.setPosition(location);
    window.draw(m_text);
}
sf::Sprite dataBar::gotScorePresent(const sf::Sprite& mycorrentsprite) {

    sf::Sprite temp(mycorrentsprite);

    if (m_PresentsUpdateClock.getElapsedTime().asSeconds() > m_timeNedeed)
        temp.setPosition(temp.getPosition().x, temp.getPosition().y + 1);
    if (temp.getPosition().y == WindowHeight - DATAPLACE)
        m_Present = m_scorePresent = m_timePresent = m_lifePresent = false;
    return temp;

}
void dataBar::setScorePresent() {
    m_scorePresent = true;
    m_Present = true;
}
void dataBar::setTimePresent() {
    m_timePresent = true;
    m_Present = true;
}
void dataBar::setLifePresent() {
    m_lifePresent = true;
    m_Present = true;
}