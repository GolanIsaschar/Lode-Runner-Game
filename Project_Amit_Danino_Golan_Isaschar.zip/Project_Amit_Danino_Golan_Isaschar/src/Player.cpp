#include "Player.h"
Player ::Player() : m_animation() , m_playerInsideHole(false) , m_enemyAllreadyInside(true){}
void Player::handleCollision(Player& /*gameObject*/) {}
void Player::handleCollision(Present& /*gameObject*/) {}
void Player :: handleCollision(GameObject& gameObject)
{
    if (&gameObject == this) return;
    gameObject.handleCollision(*this);
}
//---THIS FUNCTION HANDLE THE COIN COLLISION AND ADD 2*LEVEL TO THE SCORE
//========================================================================
void Player :: handleCollision(Coin&  /*gameObject*/)
{
    m_score += COIN_BONUS *m_level;
}
//---THIS FUNCTION HANDLE THE ENEMY COLLISION SET THE PLAYER TO BE DISPOSED
//========================================================================
void Player :: handleCollision(Enemy&  /*gameObject*/)
{
    m_isDisposed = true;
}
//---THIS FUNCTION HANDLE THE WALL COLLISION 
//========================================================================
void Player::handleCollision(WallOrFloor&  /*gameObject*/)
{
    m_floor = true;
    m_onLadder = false;
    m_OnPole = false; 
}
//---THIS FUNCTION HANDLE THE LADDER COLLISION 
//========================================================================
void Player::handleCollision(Ladder&  /*gameObject*/)
{
    m_onLadder = true;
    m_OnPole = false;
}
//---THIS FUNCTION HANDLE THE POLE COLLISION 
//========================================================================
void Player::handleCollision(Pole&  /*gameObject*/)
{
    m_OnPole = true;
    m_onLadder = false;
}
//---THIS FUNCTION HANDLE THE SCORE PRESENT 
//========================================================================
void Player::handleCollision(ScorePresent&  /*gameObject*/)
{
    m_presents[m_scorepresent] = true;
    m_score += SCORE_PRESENT_BONUS * m_level;
}
//---THIS FUNCTION HANDLE THE ENEMY PRESENT 
//========================================================================
void Player::handleCollision(EnemyPresent&  /*gameObject*/) {
    m_presents[m_newEnemy] = true;
}
//---THIS FUNCTION HANDLE THE TIME PRESENT 
//========================================================================
void Player::handleCollision(TimePresent&  /*gameObject*/) {
    m_presents[m_timepresent] = true;
}
//---THIS FUNCTION HANDLE THE LIFE PRESENT 
//========================================================================
void Player::handleCollision(LifePresent&  /*gameObject*/) {
    m_presents[m_lifepresent] = true;
}
//---THIS FUNCTION IS THE PLAYER MOVEMENT FUNCTION
//========================================================================
void Player :: move(const sf::Event& event , float deltaTime)  {
    
    if ((clock.getElapsedTime().asSeconds() > m_timeNedeed) && m_hole.second)
         m_hole.second  = false;
    if (m_playerInsideHole)
    {
        m_sprite.setPosition(m_aboveHoleLoc);
        m_playerInsideHole = false;
    }

    if ((event.key.code == sf::Keyboard::X || event.key.code == sf::Keyboard::Z))
        makeHole(event);
    
    if (m_hole.second && !m_enemyAllreadyInside &&
        m_hole.first.x - PicSize * m_sprite.getScale().x < m_sprite.getPosition().x &&
        m_sprite.getPosition().x < m_hole.first.x)
    {
        m_aboveHoleLoc = m_sprite.getPosition();
        m_playerInsideHole = true;
        m_sprite.setPosition(m_hole.first.x - PicSize * m_sprite.getScale().x / 2, m_hole.first.y);
        std::cout << "het" << std::endl; 
    }
 

    //if (m_hole.second &&
      //  m_hole.first.x < m_sprite.getPosition().x < m_hole.first.x + PicSize * m_sprite.getScale().x)
        //m_sprite.setPosition(m_hole.first);
    else
    {
        if (event.type == sf::Event::KeyPressed)
        {
            if (m_onLadder && !m_exit && m_sprite.getPosition().y >= m_ladderLoc.y)
                m_sprite.setPosition(m_ladderLoc.x, m_sprite.getPosition().y);

            if (m_OnPole)
                m_sprite.setPosition(m_sprite.getPosition().x, m_poleLoc.y);

            if (m_exit)
                m_sprite.setPosition(m_tempLoc);

            m_exit = false;
            m_tempLoc = m_sprite.getPosition();
            m_playerPos = m_tempLoc;
            m_direction = event.key.code;
            m_sprite.move(GetMove(m_direction, deltaTime, playerSpeed));
            checkIfMoovingObjectExitTheWindow();
            checkIfValid();
        }
    }
    m_floor = m_OnPole = m_onLadder = m_bumper = m_ladder = m_pole = false;
}
//---THIS FUNCTION IS BEEN CALLED WHEN THE PLAYER ENTER A POLE OR LADDER 
//---AND SET HIS LOCATION EXACLY ON THIS OBJECT
//========================================================================
void Player::setLocation(const sf::Vector2f &loc) {

    MoovingObject::setLocation(loc);
}
//---THIS FUNCTION IS THE PLAYER MAKE HOLE FUNCTION
//========================================================================
void Player:: makeHole(const sf::Event& event) {

    if (event.key.code == sf::Keyboard::X && !m_hole.second)
    {
        m_hole.first = { (m_sprite.getPosition().x + PicSize * m_sprite.getScale().x + 35) ,
            (m_sprite.getPosition().y + PicSize * m_sprite.getScale().y) };
        m_hole.second = true;
        clock.restart().asSeconds();
        m_enemyAllreadyInside = true;
    }
    else if (event.key.code == sf::Keyboard::Z && !m_hole.second)
    {
        m_hole.first = { (m_sprite.getPosition().x - PicSize * m_sprite.getScale().x + 35) ,
         (m_sprite.getPosition().y + PicSize * m_sprite.getScale().y) };
        m_hole.second = true;
        clock.restart().asSeconds();
        m_enemyAllreadyInside = true;
    }
}
//---THIS FUNCTION DOES THE PLAYER ANIMATION USING THE ANIMATION CLASS
//========================================================================
void Player:: myAnimation()  {
    m_sprite = m_animation.objectAnimation(*this, m_sprite, m_onLadder,
        m_OnPole, m_direction);
}
//---THIS FUNCTION RETURN THE PLAYER LOCATION
//========================================================================
sf::Vector2f Player :: getPlayerPos() const  {
    return m_playerPos;
}
void Player::inHole(const sf::Vector2f& loc) {

    m_enemyAllreadyInside = false;
   
}
