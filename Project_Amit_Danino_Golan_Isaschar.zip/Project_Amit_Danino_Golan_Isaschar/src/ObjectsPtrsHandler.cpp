#include "ObjectsPtrsHandler.h"
ObjectsPtrsHandler::ObjectsPtrsHandler() : m_board(), m_playerIndex(0), m_events{NULL} ,
m_enemy{ false }{}

//---THIS FUNCTION HANDLE THE COLLISIONS OF THE OBJECTS
//========================================================================
void ObjectsPtrsHandler::handleCollisions(GameObject& gameObject)
{
    for (auto& unmovable : m_unmovables.second)
        if (gameObject.checkCollision(unmovable->getGlobalBounds()))
             gameObject.handleCollision(*unmovable);

    for (auto& movable : m_movables.second)
        if (gameObject.checkCollision(movable->getGlobalBounds()))
            gameObject.handleCollision(*movable);
}
//---THIS FUCNTION CREAT THE MOVABLE OBJECTS
//========================================================================
static std::unique_ptr<MoovingObject> createMovableObject(const int& type)
{
    switch (type)
    {
        case PLAYER:
            return std::make_unique<Player>();
        case ENEMY:
        {
            int random = rand() % 3;
            switch (random)
            {
            case RANDOM_ENEMY:
                return std::make_unique<randomMoveEnemy>();
            case  CONST_ENEMY:
                return std::make_unique<constMoveEnemy>();
            case SMART_ENEMY:
                return std::make_unique<smartEnemy>();
            default:
                break;
            }
        }
    }
    return nullptr;
}
//---THIS FUNCTION CREAT THE UNMOVABLE OBJECTS
//========================================================================
static std::unique_ptr<Unmovable>  createUnmovableObject(const int& type)
{
    switch (type)
    {
    case COIN:
        return std::make_unique<Coin>();
    case WALLFLOOR:
        return std::make_unique<WallOrFloor>();
    case LADDER:
        return std::make_unique<Ladder>();
    case POLE:
        return std::make_unique<Pole>();
    case PRESENT:
        return std::make_unique<Present>();
    }
    return nullptr;
}
//---THIS FUNCTION CREAT THE GAME OBJECTS
//========================================================================
void ObjectsPtrsHandler::createObject(const int& type, const int& index)
{
    std::unique_ptr<MoovingObject> movable = createMovableObject(type);
    if (movable)
    {
        if (type == PLAYER)
            m_playerIndex = (int)m_movables.first.size();
        m_movables.first.push_back(type);
        movable->setRectangle(m_board.getBoard().second[index]);
        m_movables.second.push_back(std::move(movable));
        return;
    }
    std::unique_ptr<Unmovable> unmovable = createUnmovableObject(type);
    if (unmovable)
    {
        m_unmovables.first.push_back(type);
        unmovable->setRectangle(m_board.getBoard().second[index]);
        m_unmovables.second.push_back(std::move(unmovable));
        return;
    }
}
//---THIS FUNCTION DELETE THE DOSPOSED OBJECTS
//========================================================================
void ObjectsPtrsHandler::eraseUnmovable() {

    int i = 0;
    for (auto& unmovable : m_unmovables.second)
    {
        if (unmovable->isDisposed())
        {
            if (m_unmovables.first[i] == PRESENT)
                m_events.push_back(returnWhichPresent());
            else
                 m_events.push_back(m_unmovables.first[i]);
            m_unmovables.first[i] = DELETE;
        }
       i++;
    }
    std::experimental::erase_if(m_unmovables.second, [](auto& unmovable)
        {
            return unmovable->isDisposed();
        });
    std::experimental::erase_if(m_unmovables.first, [](auto& unmovable)
        {
            if (unmovable == DELETE)
                return true;
            return false;
        });
}
//---THIS FUNCTION RESET THE OBJECTS 
//========================================================================
void ObjectsPtrsHandler::resetInfo(const int&level)
{
    m_unmovables.first.clear();
    m_unmovables.second.clear();
    m_movables.first.clear();
    m_movables.second.clear();
    m_board.setLevelBoard(level);
    for (int i = 0; i < m_board.getBoard().first.size(); i++)
        createObject(m_board.getBoard().first[i], i);
    std::vector <sf::Sprite > keep;
    for (auto& unmovable : m_unmovables.second)
        unmovable->setWalls(keep);
    for (auto& movable : m_movables.second)
        movable->setWalls(keep);
    m_movables.second[m_playerIndex]->updatePlayerData(level+1);
}
//THIS FUNCTION DOWS THE MOVABLE MOVE
//========================================================================
void ObjectsPtrsHandler:: move(sf::Event &event , const float &deltaTime) {
    m_events.clear();
    int i = 0;
    for (auto& movable : m_movables.second)
    {
        if (i != m_playerIndex)
            movable->setPlayerPos(m_movables.second[m_playerIndex]->getPlayerPos());
        movable->move(event, deltaTime);
        while (true)
        {
            handleCollisions(*movable);
            eraseUnmovable();
            if (movable->fall())
                break;
        }
        i++;
    }
    for(auto &unmovable : m_unmovables.second)
        unmovable->setPlayerHole(m_movables.second[m_playerIndex]->getPlayerHole());
    if (m_enemy)
        addEnemy();
}
//THIS FUNCTION DRAW THE OBJECTS ON THE WINDOW
//========================================================================
void ObjectsPtrsHandler::draw(sf::RenderWindow &window) {

    for (auto& unmovable : m_unmovables.second)
    {
        unmovable->myAnimation();
        window.draw(unmovable->getMySprite());
    }
    for (auto& movable : m_movables.second)
    {
        movable->myAnimation();
        window.draw(movable->getMySprite());
    }
}
//THIS FUCNTION RETURN THE PLAYER SCORE AT THE CORRENT LEVEL
//========================================================================
int ObjectsPtrsHandler::returnScore() const {
    return m_movables.second[m_playerIndex]->returnScore();
}
//THIS FUCNTION RETURN THE TIME OF THIS FORRENT LEVEL
//========================================================================
int ObjectsPtrsHandler::returnTime(const int &level) const {
    return m_board.getTime(level);
}
//THIS FUCNTION RETURN THE AMOUNT OF LEVELS
//========================================================================
int ObjectsPtrsHandler::returnAmountOfLevels() const {
    return m_board.getAmountOfLevels();
}
//THIS FUCNTION RETURN THE EVENT WE GOT IN THIS TURN (THE OBJECTS THAT WERE
//DELETED)
//========================================================================
vector <int> ObjectsPtrsHandler::getPtrEvents() const {
    return m_events;
}
//THIS FUCNTION RETURN IF WE GOT TIME PRESENT
//========================================================================
bool ObjectsPtrsHandler::returnTimePresent() const {
    return m_movables.second[m_playerIndex]->getIfTimePresent();
}
//THIS FUCNTION RETURN IF WE GOT LIFE PRESENT
//========================================================================
bool ObjectsPtrsHandler::returnLifePresent() const
{
    return m_movables.second[m_playerIndex]->getIfLifePresent();
}
//THIS FUCNTION RETURN IF THE PLAYER WAD DISQUALIFIED
//========================================================================
bool ObjectsPtrsHandler::returnIsDispose() const
{
    return m_movables.second[m_playerIndex]->isDisposed();
}
//THIS FUCNTION RETURN IF THE LEVEL IS OVER
//========================================================================
bool ObjectsPtrsHandler::returnIfCoinOver() const {
    for (auto& unmovable : m_unmovables.first)
        if (unmovable == COIN)
            return false;
    return true;
}
//THIS FUCNTION RETURN IF WE GOT ENEMY PRESENT
//========================================================================
bool ObjectsPtrsHandler::returnEnemyPresent(){

    m_enemy = m_movables.second[m_playerIndex]->getIfNewEnemy();
    return m_enemy;
}
//THIS FUCNTION RETURN IF WE GOT SCORE PRESENT
//========================================================================
bool ObjectsPtrsHandler::returnScorePresent() const {
    return m_movables.second[m_playerIndex]->getIfScorePresent();
}
//THIS FUCNTION RETURN WHICH PRESENT WE'VE GOT
//========================================================================
int ObjectsPtrsHandler::returnWhichPresent()
{
    if (returnScorePresent())
        return SCOREPRESENT;
    if (returnEnemyPresent())
        return ENEMYPRESENT;
    if (returnTimePresent())
        return TIMEPRESENT;
    if (returnLifePresent())
        return LIFEPRESENT;
    return 0;
}
//THIS FUCNTION ADD ENEMY TO THE GAME
//========================================================================
void ObjectsPtrsHandler::addEnemy() {

    int i = 0;
    for (; i < m_board.getBoard().first.size(); i++)
        if (m_board.getBoard().first[i] == ENEMY)
            break;
    createObject(ENEMY, i);
    m_enemy = false;
}

