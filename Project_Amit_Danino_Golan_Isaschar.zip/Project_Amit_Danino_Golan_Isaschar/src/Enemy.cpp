#include "Enemy.h"
#include <algorithm>

Enemy::Enemy() : m_insideHole{ false }, m_enemyDir{ RIGHT }{}

void Enemy :: handleCollision(GameObject& gameObject) 
{
    if (&gameObject == this) return;
    gameObject.handleCollision(*this);
}
void Enemy :: handleCollision(Player& /*gameObject*/) {}
void Enemy :: handleCollision(Coin& /*gameObject*/) {}
void Enemy :: handleCollision(Enemy& /*gameObject*/) {}
void Enemy::handleCollision(Present& /*gameObject*/) {}

//---THIS FUNCTION HANDLE THE WALL COLLISION 
//========================================================================
void Enemy :: handleCollision(WallOrFloor& gameObject)
{
    m_floor = true;
    m_OnPole = false;
}
//---THIS FUNCTION HANDLE THE LADDER COLLISION 
//========================================================================
void Enemy :: handleCollision(Ladder& gameObject) 
{
    m_onLadder = true;
}
//---THIS FUNCTION HANDLE THE POLE COLLISION 
//========================================================================
void Enemy :: handleCollision(Pole& gameObject) 
{
    m_OnPole = true;
}
//---THIS FUNCTION IS BEEN CALLED FROM THE LADDER/POLE CLASS AND IT PUT THE
//---ENEMY IN MORE PRECIES LOCATION AT THE LADDER/POLE
//========================================================================
void Enemy :: setLocation(const sf::Vector2f& loc) {

    MoovingObject::setLocation(loc);
}
//THIS FUNCTION SET THE ENEMY POSITION INSIDE THE HOLE 
//===================================================================
void Enemy :: inHole(const sf::Vector2f& loc) {

    if (!m_insideHole)
    {
        m_aboveHole = m_sprite.getPosition();
        m_sprite.setPosition(loc);
        m_insideHole = true;
        m_holeclock.restart().asSeconds();
    }
}
//THIS FUNCTION GIVE THE ENEMY THE PLAYER LOCATION
//===================================================================
void Enemy :: setPlayerPos(const sf::Vector2f& loc)  {
    m_playerPos = loc;
}
//---THIS FUNCTION DOES THE ENEMY ANIMATION USING THE ANIMATION CLASS
//========================================================================
void Enemy :: myAnimation() {
    m_sprite = m_animation.objectAnimation(*this, m_sprite, m_onLadder,
        m_OnPole, m_direction);
}
