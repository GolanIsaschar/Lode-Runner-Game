#include "MoovingObject.h"

MoovingObject::MoovingObject() : m_level(1) , 
    m_score(0) , m_exit(false)  , m_direction(0) , m_onLadder(false) , 
    m_OnPole(false) , m_floor(false) , m_ladder(false) , m_pole(false){
}
//---THIS FUNCTION RETURN THE NEW MOOVING OBJECT LOCATION
//========================================================================
sf::Vector2f MoovingObject::GetMove(const unsigned int& direction, float deltaTime,
    const float& speed)
{
    sf::Vector2f Move = { 0.f , 0.f };
    switch (direction)
    {
    case sf::Keyboard::Up:
            Move.y = -speed * deltaTime;
        break;
    case sf::Keyboard::Down:
            Move.y = speed * deltaTime;
        break;
    case sf::Keyboard::Right:
        Move.x = speed * deltaTime;
        break;
    case sf::Keyboard::Left:
        Move.x = -speed * deltaTime;
        break;
    default:
        break;
    }
    return
        Move;
}
//---THIS FUNCTION GET THE MOOVING OBJECT TO FALL IF IT NOT ABOVE FLOOR OR
//---PRESSING DOWN WHEN IT ON A POLE
//========================================================================
bool MoovingObject::fall() {

    if ((!m_floor && !m_onLadder && !m_OnPole &!m_exit) ||
       ( m_OnPole && m_direction == DOWN))
    {
        m_bumper = true; 
        m_sprite.setPosition(m_sprite.getPosition().x , m_sprite.getPosition().y + 1);  
        return false;
    }
    else
        return true;
}
//---THIS FUNCTION CHECK IF THE MOOVING OBJECT EXIT THE WINDOW OR GOT INTO
//---A WALL
//========================================================================
void MoovingObject::checkIfMoovingObjectExitTheWindow() {

    m_exit = false;

    if (m_sprite.getPosition().x < 0 || m_sprite.getPosition().y < 0 ||
        m_sprite.getPosition().x >(WindowWidth - m_sprite.getTexture()->getSize().x) ||
        m_sprite.getPosition().y >(WindowHeight - DataBarSize -
            m_sprite.getTexture()->getSize().y))
        m_exit = true;

    if (m_direction != DOWN)
        for (int i = 0; i < m_keepWalls.size(); i++)
            if (m_keepWalls[i].getGlobalBounds().contains(m_sprite.getPosition()))
                m_exit = true;
            
}
//---THIS FUNCTION CHECK IF THE FUNCTION IS VALID AT THE LADDER AND POLE 
//---VALID REQUIREMENT
//========================================================================
void MoovingObject::checkIfValid() {

    if (m_direction == DOWN && !m_onLadder && !m_OnPole)
        m_exit = true;

    if (m_direction == UP && !m_onLadder)
        m_exit = true;
}
//---THIS FUNCTION RETURN THE  PLAYER SCORE
//========================================================================
int MoovingObject::returnScore() const {
    return m_score;
}
//---THIS FUNCTION RETURN IF THE USER GOT TIME PRESENT
//========================================================================
bool MoovingObject :: getIfTimePresent() {
    bool a = m_presents[m_timepresent];
    m_presents[m_timepresent] = false;
    return a;
}
//---THIS FUNCTION RETURN IF THE USER GOT SCORE PRESENT
//========================================================================
bool MoovingObject::getIfScorePresent() {
    bool a = m_presents[m_scorepresent];
    m_presents[m_scorepresent] = false;
    return a;
}
//---THIS FUNCTION RETURN IF THE USER GOT LIFE PRESENT
//========================================================================
bool MoovingObject::getIfLifePresent() {
    bool a = m_presents[m_lifepresent];
    m_presents[m_lifepresent] = false;
    return a;
}
//---THIS FUNCTION RETURN IF THE USER GOT ENEMY PRESENT
//========================================================================
bool MoovingObject :: getIfNewEnemy() {
  
    bool a = m_presents[m_newEnemy];
    m_presents[m_newEnemy] = false;
    return a;
}
//---THIS FUNCTION SET THE LOCATION OF THE OBJECT TO BE AT THE CENTER
// OF THE POLE OR THE LADDER WHEN THE OBJECT ENTER IN POLE OR LADDER 
//========================================================================
void MoovingObject::setLocation(const sf::Vector2f &loc) {
    if (m_onLadder)
    {
        if (!m_ladder)
            m_ladderLoc = loc;
        m_ladder = true;
    }
    if (m_OnPole)
    {
        if (!m_pole)
            m_poleLoc = loc;
        m_pole = true;
    }
}
//---THIS FUNCTION GET THE WALLS SPRITE FOR THE VALID CHECK
//========================================================================
void MoovingObject :: setWalls(std::vector <sf::Sprite> &keep) {
    m_keepWalls = keep;
}
//========================================================================
void MoovingObject :: updatePlayerData(const int& level) {
    m_level = level;
}