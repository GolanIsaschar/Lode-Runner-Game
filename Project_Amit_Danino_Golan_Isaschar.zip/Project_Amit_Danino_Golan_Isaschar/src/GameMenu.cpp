#include "UseClasses.h"
void gameMenu::menu(sf::RenderWindow& window) {

    sf::Event event;
    while (window.waitEvent(event))
    {
        if (event.type == sf::Event::KeyPressed)
        {
            if (event.key.code == sf::Keyboard::E ||
                event.key.code == sf::Keyboard::P)
            {
                if (event.key.code == sf::Keyboard::E)
                    window.close();
                break;
            }
        }
    }
}