#include "UseClasses.h"

timer::timer() : m_timeLeft(0), m_timerAlart{ false }, m_time(0){}

//---THIS FUNCTION SET THE TIME LEFT AND RETURN 2 VALUES - 
//1)IF THE TIME ALART IS ON - WE GOT LESS THAN 5 SECOND TO END THIS LEVEL
//2)IF THE TIME IS OVER 
//========================================================================
std :: pair <bool , bool > timer::doesTimeAlarm() {

    bool timeAlarm = false, timeEnd = false;
	if (m_time != -1)
	{
       m_time = m_timeLeft - m_aITimer.getElapsedTime().asSeconds();
       if (m_time <= 5 && !m_timerAlart)
           m_timerAlart = timeAlarm = true;
       if (m_time <= 0)
           timeEnd = true;
    }
    return { timeAlarm  , timeEnd };
}
//---THIS FUNCTION RESET THE TIMER
//========================================================================
void timer :: resetTime(const int &time) {

    m_time = m_timeLeft = time;
    m_timerAlart = false;
    m_aITimer.restart();
}
//---THIS FUNCTION RETURN THE TIME THE PLAYER LEFT IN THIS LEVEL
//========================================================================
int timer::getTime() const {
    return m_time;
}
//---THIS FUNCTION RETURN IF THE TIME ALARM IS ON
//========================================================================
bool timer::getTimeAlart() const {
    return m_timerAlart;
}
//---THIS FUNCTION ADD 10 SECOND TO THE TIMER AND IT WILL BE CALLED IF 
//---THE PLAYER GOT LIFE PRESENT
//========================================================================
void timer::addTimePresent() {
    m_timeLeft += 10;
}