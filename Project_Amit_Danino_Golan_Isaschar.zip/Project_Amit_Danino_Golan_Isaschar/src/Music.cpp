#include "UseClasses.h"

//---THIS FUNCTION CHECK IF THERE WAS EVENT MUSIC THAT WAS OVER AND 
//---RETURN THE GAME MUSIC ON AGAIN
//========================================================================
void music::continueGameMusic() {
	if (m_music[0].getStatus() != 2 && m_music[1].getStatus() == 1)
		m_music[1].play();
}
//---THIS FUNCTION PLAY THE GAME MUSIC ACCORDING TO THE GIVVEN MUSIC 
//========================================================================
void music::playMusic(const string& musicfile, const bool& loop) {

    m_music[0].stop();
    if (!loop)
        m_music[1].pause();
    m_music[loop].openFromFile(musicfile);
    m_music[loop].setVolume(MusicValume);
    m_music[loop].play();
    m_music[loop].setLoop(loop);
}
//---THIS FUNCTION IS BEEN CALLED EVERY NEW GAME , ITS WAITS FOR THE 
//---LOST / WIN MUSIC TO END AND PLAY THE MENU GAME MUSIC
//========================================================================
void music::newGameMusic(const string& musicfile, const bool& loop) {

    while (m_music[0].getStatus() == 2);
    playMusic(MusicNames[NEWGAMEMUSIC], false);
}
//---THIS FUNCTION PLAY THE GAME MUSIC WHEN WE EXIT THE GAME MENU
//========================================================================
void music::exitMenuMusic(const string& musicfile, const bool& loop)
{
    m_music[0].stop();
    playMusic(MusicNames[GAMEMUSIC], true);
}