#include "Board.h"

Board::Board() : m_myOriginalLevels{NULL}, m_sprites{NULL , NULL} 
{
    openFile();
    setKeep();
}
//---THIS FUNCTION OPEN THE BOARD FILE AND GO TO THE FUNCTION THAT INSERT
//---THE BOARD TO CHAR VECTOR
//========================================================================
void Board::openFile() {

    ifstream infile;
    infile.open("Board.txt");

    //check if the file openning succed
    if (!infile.good())
        cout << "File is not open";

    insertLevelsFromFile(infile);
    infile.close();
}
//---THIS FUNCTION USE A VECTOR OF - VECTORS OF VECTORS OF CHARS , IT 
//---INSERT THE FILE INTO THE VECTOR.
//---EACH MAIN VECTOR CONTAIN A LEVEL
//========================================================================
void Board::insertLevelsFromFile(ifstream& infile) {

    string line;
    char value;
    int rows , cols , time;

    while (!infile.eof())
    {
        m_myOriginalLevels.push_back(std :: vector<vector<char>>());
        infile >> rows;
        infile >> cols;
        infile >> time;

        m_Height.push_back((WindowHeight - DATAPLACE) / rows);
        m_Width.push_back(WindowWidth / cols);
        m_Time.push_back(time);
      
        getline(infile, line);

        for (int i = 0; i < rows; i++)
        {
            getline(infile, line);
            m_myOriginalLevels.back().push_back(std::vector<char>());

            for (int j = 0; j < cols; j++)
            {
                value = line[j];
                m_myOriginalLevels.back().back().push_back(value);
            }
        }
    }
}
// THIS FUNCTION SET THE IMAGES WE NEED FOR BOARD
//========================================================================
void Board::setKeep()
{
    sf::Texture temp;

    for (int i = 0; i < NUMOFIMAGES ; i++)
    {
        temp.loadFromFile(FileNames[i]);
        m_keep.push_back(temp);
    }
}
//---THIS FUNCTION INPUT THE CHAR TO SPRITE TO THE SPRITE VECTOR , 
//---ACCORDING TO THE LEVEL NUMBER , IT WILL BE CALLED EVERY NEW LEVEL
//---M_SPRITES.FIRST - INDEX THAT TELL US WHICH ELEMENT WE HAVE AT THAT CELL
//---M_SPRITE.SECOND - THE ELEMENT SPRITE.
//========================================================================
void Board::setLevelBoard(const int& level)
{
    sf::Vector2f position{0,0};
    int Case;
    double z = m_Width[level], w = m_Height[level] , x = z / PicSize, 
    y = w / PicSize;
    m_sprites.second.clear();
    m_sprites.first.clear();
 
    for (int i = 0; i < m_myOriginalLevels[level].size(); i++)
    {
        position.y = i * m_Height[level];

        for (int j = 0; j < m_myOriginalLevels[level][i].size(); j++)
        {
            position.x = j * m_Width[level];
            Case = CharCases(m_myOriginalLevels[level][i][j]);
            sf::Sprite sprite;
            sprite = sf::Sprite(m_keep[Case]);
            sprite.setPosition(position);
            sprite.scale(x, y);
            if (Case != DELETE)
            {
                m_sprites.first.push_back(Case);
                m_sprites.second.push_back(sprite);
            }
        }
    } 
    m_OriginalSprite = m_sprites;
}
//========================================================================
pair<std::vector<int>, std::vector<sf::Sprite>> Board::getBoard() const
{
    return m_sprites;
}
//---THIS FUNCTION RETURN THE TIME OF THE CORRENT LEVEL
//========================================================================
unsigned int Board::getTime(const int& level) const
{
    return m_Time[level];
}
//---THIS FUNCTION GET THE CHAR FROM THE VECTOR THAT READ THE BOARD AND
//---RETURN THE CONST THAT FIT THE CHAR , ACCORDING TO THIS WE WILL KNOW
//---WHICH IMAGE TO LOAD TO THE SPRITE VECTOR
//========================================================================
int Board::CharCases(const char& Char) {

    switch (Char)
    {
    case COIN_CHAR:
        return COIN;
        break;
    case ENEMY_CHAR:
        return ENEMY;
        break;
    case LADDER_CHAR:
        return LADDER;
        break;
    case PLAYER_CHAR:
        return PLAYER;
        break;
    case POLE_CHAR:
        return POLE;
        break;
    case WALLFLOOR_CHAR:
        return WALLFLOOR;
        break;
    case ' ':
        return DELETE;
        break;
    case PRESENT_CHAR:
        return PRESENT;
        break;
    default:
        return 10;
        break;
    }
}
//---THIS FUNCTION RETURN THE AMOUNT OF LEVEL IN THE GAME ACCORDING TO
//---THE VECTOR SIZE
//========================================================================
unsigned int Board::getAmountOfLevels() const {

    return m_Time.size();
}