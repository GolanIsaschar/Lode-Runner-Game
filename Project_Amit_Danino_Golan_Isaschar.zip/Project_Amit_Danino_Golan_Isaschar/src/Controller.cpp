#include "Controller.h"

Controller::Controller() : m_ptrClass(), m_timer(),
m_level(1), m_dataBar(), m_doesLifeAnimation{false}, m_life(0),
m_saveLastLevelsScore(0) , m_music(), m_gameMenu(),
m_window(sf::RenderWindow(sf::VideoMode(WindowWidth, WindowHeight), "window")) 
{
    m_backround.loadFromFile(BACKGROUNDPIC);
    m_backgroundPic.setTexture(m_backround);
}
//---THIS FUNCTION IS THE FUNCTION THAT RUN THE GAME
//========================================================================
void Controller::run()
{
    sf::Event event;
    sf::Clock clock;
    NewGame(NEWGAMEPIC);

    while (m_window.isOpen())
    {
        updata();
        const auto deltaTime = clock.restart().asSeconds();
        while (m_window.pollEvent(event))
                if (event.type == sf::Event::Closed)
                    m_window.close(); 
        m_ptrClass.move(event , deltaTime);
        handleMove();   
    }
}
//---THIS FUNCTION IS BEEN CALLED AT THE BEGINING OF THE GAME AND EVERY TIME
//---THE USER END THE GAME AND OPEN A MENU THAT ASK THE USER IF HE WANT 
//---TO PLAY ANOTHER GAME OR TO EXIT THE GAME
//========================================================================
void Controller::NewGame(const std::string& PicName) 
{   
    m_life = LIFES;
    m_level = FIRSTLEVEL;
    sf::Texture tex;
    sf::Sprite sprite;
    tex.loadFromFile(PicName);
    sprite.setTexture(tex);
    m_window.clear();
    m_window.draw(sprite);
    m_window.display();
    m_music.newGameMusic(MusicNames[NEWGAMEMUSIC], false);
    m_gameMenu.menu(m_window);
    m_music.exitMenuMusic(MusicNames[GAMEMUSIC], true);
    resetInfo();
}
//---THIS FUNCTION DRAW THE BOARD GAME AND THE DATA BAR UNDER THE BOARD
//========================================================================
void Controller::draw() 
{
    m_window.clear();
    m_window.draw(m_backgroundPic);
    m_ptrClass.draw(m_window);
    m_dataBar.draw(m_window, m_level, m_life, (m_ptrClass.returnScore() + m_saveLastLevelsScore),
        m_doesLifeAnimation, m_timer.getTime(), m_timer.getTimeAlart());
    m_window.display();
}
//---THIS FUNCTION IS BEEN CALLED EVERY TIME THE USER WON THE GAME
//========================================================================
void Controller::win() 
{
    m_music.playMusic(MusicNames[VICTORY], false);
    NewGame(YOUWINPIC);
}
//---THIS FUNCTION IS BEEN CALLED EVERY TIME THE USER LOSE THE GAME
//========================================================================
void Controller::lost() 
{
    m_music.playMusic(MusicNames[LOST], false);
    NewGame(GAMEOVERPIC);
}
//========================================================================
void Controller::resetInfo() 
{
    m_ptrClass.resetInfo(m_level-1);
    m_timer.resetTime(m_ptrClass.returnTime(m_level - 1));
}
//---THIS FUNCTION UPDATE THE GAME ACCORDING TO THE MOVMENT RESULT
//========================================================================
void Controller::handleMove() 
{
    for (int i = 0; i < m_ptrClass.getPtrEvents().size(); i++)
    {
        if (m_ptrClass.getPtrEvents()[i] == LIFEPRESENT)
        {
            m_life++;
            m_dataBar.setLifePresent();
        }
        if (m_ptrClass.getPtrEvents()[i] == TIMEPRESENT)
        {
            m_timer.addTimePresent();
            if(m_ptrClass.returnTime(m_level - 1) != -1)
                m_dataBar.setTimePresent();
        }
        if (m_ptrClass.getPtrEvents()[i] == SCOREPRESENT)
            m_dataBar.setScorePresent();
        m_music.playMusic(MusicNames[m_ptrClass.getPtrEvents()[i]], false);
    }

    if (m_ptrClass.returnIsDispose())
        Disqualified();

    if (m_life == 0)
        lost();

    if (m_ptrClass.returnIfCoinOver()) {
    
        m_saveLastLevelsScore += m_ptrClass.returnScore() + NEXT_LEVEL_BONUS * m_level;
    
        if (m_ptrClass.returnAmountOfLevels() == m_level)
            win();
        
        else
        {
            m_level++;
            m_music.playMusic(MusicNames[NEWLEVEL], false);
            resetInfo();
        }
    }
}
//---THIS FUNCTION IS BEEN CALLED WHEN THE PLAYER GET DISQUALIFIED
//========================================================================
void Controller::Disqualified() 
{
    m_doesLifeAnimation = true;
    m_music.playMusic(MusicNames[MINUSLIFE], false);
    m_life--;
    resetInfo();
}
//---THIS FUNCTION DOES ALL THE THING WE NEED TO UPDATE IN THE GAME
//========================================================================
void Controller::updata() 
{
    std::pair <bool, bool> time{ m_timer.doesTimeAlarm() };
    if (time.first)
        m_music.playMusic(MusicNames[CLOCK], false);
    if (time.second)
        Disqualified();
    m_music.continueGameMusic();
    draw();
}