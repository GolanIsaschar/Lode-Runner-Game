#include "Enemy.h"
void constMoveEnemy::move(const sf::Event& event, float deltaTime) {

	if ((m_holeclock.getElapsedTime().asSeconds() > m_holetimeNedeed) && m_insideHole)
	{
		m_sprite.setPosition(m_aboveHole);
		m_tempLoc = m_sprite.getPosition();
		m_insideHole = false;
	}
	if (!m_insideHole)
	{

		if (m_exit)
			m_enemyDir = rand() % 2 + 71;

		m_direction = m_enemyDir;

		m_sprite.move(GetMove(m_enemyDir, deltaTime, m_enemySpeed));
		checkIfMoovingObjectExitTheWindow();
	}
	m_floor = m_OnPole = m_onLadder = m_bumper = m_ladder = m_pole = false;
}