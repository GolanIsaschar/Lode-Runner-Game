#include "WallOrFloor.h"

void WallOrFloor :: handleCollision(GameObject& gameObject) 
{
    if (&gameObject == this) return;
    gameObject.handleCollision(*this);
}
//---THIS FUNCTION HANDLE THE PLATER COLLISION WITH WALL OR FLOOR
//========================================================================
void WallOrFloor :: handleCollision(Player& gameObject) 
{
    if (m_was && !m_allreadysent)
    {
        gameObject.inHole(this->getMySprite().getPosition());
        m_allreadysent = true;
    }
    gameObject.handleCollision(*this);
}
//---THIS FUNCTION HANDLE THE ENEMY COLLISION WITH WALL OR FLOOR , 
//---THIS FUNCTION PUT THE ENEMY INSIDE THE HOLE IF ITS ABOVE IT
//========================================================================
void WallOrFloor ::  handleCollision(Enemy& gameObject) 
{
    if (m_was && !m_allreadysent)
    {
        sf::Vector2f loc = { this->getMySprite().getPosition().x , this->getMySprite().getPosition().y + 10 };
        gameObject.inHole(loc);
        m_allreadysent = true;
    }
    gameObject.handleCollision(*this);
}
//---THIS FUNCTION KEEP THE WALLS/FLOORS SPRITES FOR THE VALID USE
//========================================================================
void WallOrFloor :: setWalls(std::vector <sf::Sprite >& keep)  {
    keep.push_back(m_sprite);
}
//---THIS FUNCTION DOES THE HOLE IF THE PLAYER DID ONE
//========================================================================
void WallOrFloor :: setPlayerHole(std::pair<sf::Vector2f, bool > loc)  {

    if (m_sprite.getGlobalBounds().contains(loc.first) && loc.second && !m_was)
    {
        m_sprite.setColor(sf::Color(255, 255, 255, 0));
        clock.restart().asSeconds();
        m_was = true;
    }
    if ((clock.getElapsedTime().asSeconds() > m_timeNedeed) && m_was)
    {
        m_sprite.setColor(sf::Color(255, 255, 255, 255));
        m_was = m_allreadysent = false;
    }
}