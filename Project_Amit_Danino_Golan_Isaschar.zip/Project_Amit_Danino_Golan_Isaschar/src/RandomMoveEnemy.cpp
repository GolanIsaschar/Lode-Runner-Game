#include "Enemy.h"

void  randomMoveEnemy :: move(const sf::Event& event, float deltaTime) {

    if ((m_holeclock.getElapsedTime().asSeconds() > m_holetimeNedeed) && m_insideHole)
    {
        m_sprite.setPosition(m_aboveHole);
        m_tempLoc = m_sprite.getPosition();
        m_insideHole = false;
    }
    if (!m_insideHole)
    {
        if (m_OnPole)
            m_direction = DOWN;
        else
        {
            m_tempLoc = m_sprite.getPosition();
            if ((m_randomMoveClock.getElapsedTime().asSeconds() > m_randomTimeMove || m_exit) &&
                !m_pole)
            {
                m_enemyDir = rand() % 2 + 71;
                m_direction = m_enemyDir;
                m_randomMoveClock.restart().asSeconds();
            }
            else if ((m_randomMoveClock.getElapsedTime().asSeconds() > m_randomTimeMove || m_exit)
                && m_ladder && !m_OnPole)
            {
                m_enemyDir = rand() % 2 + 73;
                m_direction = m_enemyDir;
                m_randomMoveClock.restart().asSeconds();
            }

            m_sprite.move(GetMove(m_enemyDir, deltaTime, m_enemySpeed));
            m_exit = false;
            checkIfMoovingObjectExitTheWindow();
            if (m_exit)
                m_sprite.setPosition(m_tempLoc);
        }
    }
    m_floor = m_OnPole = m_onLadder = m_bumper = m_ladder = m_pole = false;
}