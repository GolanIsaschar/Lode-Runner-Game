#include "Animation.h"
animation::animation() {
   
    setCoinTextures();
    setEnemyTextures();
    setPlayerTextures();
    setLifeTextures();

}
//---THIS FUNCTION LOAD TO THE TEXTURE VECTOR THE COIN ANIMATION IMAGES
//========================================================================
void animation::setCoinTextures() {

    sf::Texture temp;

    for (int i = 0; i < NUMOFIMAGES; i++)
    {
        temp.loadFromFile(coinPic[i]);
        m_coinTexture.push_back(temp);

    }
}
//---THIS FUNCTION LOAD TO THE TEXTURE VECTOR THE ENEMY ANIMATION IMAGES
//========================================================================
void animation::setEnemyTextures() {

    sf::Texture temp;

    for (int i = 0; i < 5; i++)
    {
        temp.loadFromFile(enemyRightPic[i]);
        m_enemyRightTexture.push_back(temp);
        temp.loadFromFile(enemyLeftPic[i]);
        m_enemyLeftTexture.push_back(temp);
    }

    temp.loadFromFile("enemyLadder1.png");
    m_enemyLadderTexture.push_back(temp);
    temp.loadFromFile("enemyLadder2.png");
    m_enemyLadderTexture.push_back(temp);
}
//---THIS FUNCTION LOAD TO THE TEXTURE VECTOR THE PLAYER ANIMATION IMAGES
//========================================================================
void animation::setPlayerTextures() {

    sf::Texture temp;

    for (int i = 0; i < 5; i++)
    {
        temp.loadFromFile(playerRightPic[i]);
        m_playerRightTexture.push_back(temp);
        temp.loadFromFile(playerLeftPic[i]);
        m_playerLeftTexture.push_back(temp);
    }

    temp.loadFromFile("playerLadder1.png");
    m_playerLadderTexture.push_back(temp);
    temp.loadFromFile("playerLadder2.png");
    m_playerLadderTexture.push_back(temp);
}
//---THIS FUNCTION LOAD TO THE TEXTURE VECTOR THE COIN ANIMATION IMAGES
//========================================================================
sf::Sprite animation::objectAnimation(Coin& gameObject , const sf::Sprite& mycorrentsprite) {

    sf::Sprite temp(mycorrentsprite);

    if (m_coinClock.getElapsedTime().asSeconds() > m_timeNedeed)
      {
          temp.setTexture(m_coinTexture[m_coinPicIndex]);
          m_coinClock.restart().asSeconds();
          m_coinPicIndex++;
          m_coinPicIndex = m_coinPicIndex % 9;
     }
    return temp;
}
//---THIS FUNCTION LOAD TO THE TEXTURE VECTOR THE LIFE ANIMATION IMAGES
//========================================================================
void animation::setLifeTextures() {

    sf::Texture temp;

    for (int i = 0; i < 4; i++)
    {
        temp.loadFromFile(lifePic[i]);
        m_lifeTexture.push_back(temp);
    }
}
//---THIS FUNCTION DOES THE PLAYER ANIMATION
//========================================================================
sf::Sprite animation::objectAnimation(Player& gameObject, const sf::Sprite& mycorrentsprite,
    const bool& onLadder, const bool& onPole, const int& direction) {

    sf::Sprite temp(mycorrentsprite);

        if (direction == RIGHT && !onPole)
        {
            if (m_playerClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                temp.setTexture(m_playerRightTexture[m_playerPicIndex]);
                m_playerClock.restart().asSeconds();
                m_playerPicIndex++;
                m_playerPicIndex = m_playerPicIndex % 5;
            }
        }
        if (direction == LEFT && !onPole)
        {
            if (m_playerClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                temp.setTexture(m_playerLeftTexture[m_playerPicIndex]);
                m_playerClock.restart().asSeconds();
                m_playerPicIndex++;
                m_playerPicIndex = m_playerPicIndex % 5;
            }
        }
        if (onLadder || onPole)
        {
            if (m_playerClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                m_playerPicIndex = m_playerPicIndex % 2;
                temp.setTexture(m_playerLadderTexture[m_playerPicIndex]);
                m_playerClock.restart().asSeconds();
                if (!onPole)
                    m_playerPicIndex++;
                m_playerPicIndex = m_playerPicIndex % 2;
            }
        }
   return temp;
}
//---THIS FUNCTION DOES THE ENEMY ANIMATION
//========================================================================
sf::Sprite animation::objectAnimation(Enemy& gameObject, const sf::Sprite& mycorrentsprite , 
    const bool& onLadder, const bool& onPole, const int& direction) {

    sf::Sprite temp(mycorrentsprite);

        if (direction == RIGHT && !onPole)
        {
            if (m_enemyClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                temp.setTexture(m_enemyRightTexture[m_enemyPicIndex]);
                m_enemyClock.restart().asSeconds();
                m_enemyPicIndex++;
                m_enemyPicIndex = m_enemyPicIndex % 5;
            }
        }
        if (direction == LEFT && !onPole)
        {
            if (m_enemyClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                temp.setTexture(m_enemyLeftTexture[m_enemyPicIndex]);
                m_enemyClock.restart().asSeconds();
                m_enemyPicIndex++;
                m_enemyPicIndex = m_enemyPicIndex % 5;
            }
        }
        if (onLadder || onPole)
        {
            if (m_enemyClock.getElapsedTime().asSeconds() > m_timeNedeed)
            {
                m_enemyPicIndex = m_enemyPicIndex % 2;
                temp.setTexture(m_enemyLadderTexture[m_enemyPicIndex]);
                m_enemyClock.restart().asSeconds();
                if (!onPole)
                    m_enemyPicIndex++;
                m_enemyPicIndex = m_enemyPicIndex % 2;
            }
        }
    return temp;
}
//---THIS FUNCTION DOES THE LIFE ANIMATION
//========================================================================
sf::Sprite animation::life(const sf::Sprite& mycorrentsprite , bool& finish) {

    sf::Sprite temp(mycorrentsprite);
    
    if (m_lifeClock.getElapsedTime().asSeconds() > m_timeNedeed)
    {
        m_lifePicIndex++;
        if(m_lifePicIndex == 4)
            finish = true;
        m_lifePicIndex = m_lifePicIndex % 4;
        temp.setTexture(m_lifeTexture[m_lifePicIndex]);
        m_lifeClock.restart().asSeconds();
    }
    return temp;
}