#include "Enemy.h"

void smartEnemy::move(const sf::Event& event, float deltaTime) {

    if ((m_holeclock.getElapsedTime().asSeconds() > m_holetimeNedeed) && m_insideHole)
    {
        m_sprite.setPosition(m_aboveHole);
        m_tempLoc = m_sprite.getPosition();
        m_insideHole = false;
    }
    if(!m_insideHole)
    {
        if (m_onLadder && !m_exit && m_sprite.getPosition().y >= m_ladderLoc.y && !m_exitLadder)
            m_sprite.setPosition(m_ladderLoc.x, m_sprite.getPosition().y);

        if (m_OnPole)
            m_sprite.setPosition(m_sprite.getPosition().x, m_poleLoc.y);

        byDistance();
        m_tempLoc = m_sprite.getPosition();
        m_exitLadder = false;

        //we need to go up
        if (m_playerPos.y < m_sprite.getPosition().y)
        {
            if (!m_onLadder || m_bumper || m_OnPole)
                moveLeftOrRight();
            else
            {
                m_sprite.setPosition(m_loc[up]);
                m_direction = UP;
            }
        }

        //we need to go down
        else if (m_playerPos.y > m_sprite.getPosition().y)
        {
            if ((!m_onLadder && !m_OnPole) || (m_onLadder && m_floor) || (m_OnPole))
            {
                moveLeftOrRight();
                m_exitLadder = true;
            }
            else
            {
                m_sprite.setPosition(m_loc[down]);
                m_direction = DOWN;
            }
        }
        else
            moveLeftOrRight();

        if (m_floor && (m_playerPos.y == m_sprite.getPosition().y))
            moveLeftOrRight();
    }
   
    m_floor = m_OnPole = m_onLadder = m_bumper = m_ladder = m_pole = false;
}
//========================================================================
bool smartEnemy::compareDistance(const sf::Vector2f& loc1, const sf::Vector2f& loc2) {

    return (sqrt(pow((loc1.x - m_playerPos.x), 2) + pow((loc1.y - m_playerPos.y), 2)) <
        sqrt(pow((loc2.x - m_playerPos.x), 2) + pow((loc2.y - m_playerPos.y), 2)));
}
void smartEnemy::calculatePossibleLocations() {

    m_loc.clear();
    sf::Vector2f up{ m_sprite.getPosition().x ,  m_sprite.getPosition().y - 0.5f };
    sf::Vector2f down{ m_sprite.getPosition().x ,  m_sprite.getPosition().y + 0.5f };
    sf::Vector2f left{ m_sprite.getPosition().x - 0.5f  ,  m_sprite.getPosition().y };
    sf::Vector2f right{ m_sprite.getPosition().x + 0.5f ,  m_sprite.getPosition().y };
    m_loc.push_back(left);
    m_loc.push_back(right);
    m_loc.push_back(up);
    m_loc.push_back(down);
}

//THIS FUNCTION GET THE ENEMY LOCATION AND SORT THE MOVEMENT OPTION
//ACCORDING TO THE PLAYER DISTANCE FROM EACH ONE
//===================================================================
void smartEnemy::byDistance() {

    calculatePossibleLocations();
    m_sortedDirections.clear();
    for (int i = 0; i < 4; i++)    
        m_sortedDirections.push_back(std::make_pair(locationDis(i), i));
   
    sort(m_sortedDirections.begin(), m_sortedDirections.end());
}
//THIS FUNCTION CALCULATE THE DISTANCE OF THE PLAYER FROM A GIVVEN ENEMY
//VERTEX, IT HELP US DISIDE WHICH DIRECTION THE ENEMY SHOULD GO
//===================================================================
double smartEnemy::locationDis(const int& i) {

    return sqrt(pow((m_loc[i].x - m_playerPos.x), 2) + 
        pow((m_loc[i].y - m_playerPos.y), 2));
}
void smartEnemy::moveLeftOrRight() {

    for (int i = 0; i < m_sortedDirections.size(); i++)
        if (m_sortedDirections[i].second == left || m_sortedDirections[i].second == right)
        {
            m_sprite.setPosition(m_loc[m_sortedDirections[i].second]);
            m_direction = m_sortedDirections[i].second + LEFT;
            checkIfMoovingObjectExitTheWindow();
            if (!m_exit)
                break;
            else
                m_sprite.setPosition(m_tempLoc);
        }
}