﻿#include "Controller.h"

int main()
{
    Controller gamecontroller;
    gamecontroller.run();
}